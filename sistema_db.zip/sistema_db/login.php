<?php
    include_once('header.php');
?>
    <fieldset>
        <legend>Tela de Login</legend>
        <div>
            <label for="login">Login: </label>
            <input type="text" name="login" id="login">
        </div>
        <div>
            <label for="senha">Senha: </label>
            <input type="password" name="senha" id="senha">
        </div>
        <div>
            <input type="submit" value="Entrar">
        </div>
    </fieldset>    

<?php
    include_once('footer.php')
?>
